const { heapSort } = PacktDataStructuresAlgorithms;

console.log('********** Heap Sort **********');
const array = [7, 6, 3, 5, 4, 1, 2];

console.log('Before sorting: ', array);
console.log('After sorting: ', heapSort(array));
