import { bubbleSort } from '../../../../src/js/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(bubbleSort, 'Bubble Sort');
