import { insertionSort } from '../../../../src/js/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(insertionSort, 'Insertion Sort');
